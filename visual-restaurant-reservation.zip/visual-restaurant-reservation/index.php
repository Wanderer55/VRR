<?php

/*
Plugin Name: Visual Restaurant Reservation Plugin
Plugin URI: http://visual-restaurant-reservation.gogetlab.com/
Description: Visual Restaurant Reservation Plugin
Version: 1.3
Author: GoGetLab.com
Author URI: http://gogetlab.com
Text Domain: vrr
*/


