<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

namespace VISUAL_RESTAURANT_RESERVATION;

class Shortcode {
	
}
